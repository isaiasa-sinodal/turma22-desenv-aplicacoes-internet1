const sonic = document.getElementById('sonic');
const gameBoard = document.getElementById('game-board');
const scoreText = document.getElementById('score-text');
let score = 0;
let isJumping = false;
let gameSpeed = 4;
let obstacleSpawnInterval;
let gameActive = true;

const JUMP_HEIGHT = 120;
const JUMP_DURATION = 500;
let sonicBottom = 0;


sonic.style.bottom = sonicBottom + 'px';

function jump() {
    if (!isJumping && gameActive) {
        isJumping = true;

        sonic.classList.add('is-jumping'); 

        const startTime = Date.now();
        const initialBottom = sonicBottom;

        function animateJump() {
            if (!isJumping) return;
            
            const elapsedTime = Date.now() - startTime;
            const progress = elapsedTime / JUMP_DURATION;
            let newBottom;

            if (progress < 0.5) {

                newBottom = initialBottom + JUMP_HEIGHT * (1 - Math.pow(1 - progress * 2, 2));
            } else if (progress < 1.0) {

                newBottom = initialBottom + JUMP_HEIGHT * (1 - Math.pow((progress - 0.5) * 2, 2));
            } else {

                newBottom = initialBottom;
                isJumping = false;
                sonic.classList.remove('is-jumping');
                sonic.style.bottom = initialBottom + 'px';
                return;
            }

            sonicBottom = newBottom;
            sonic.style.bottom = sonicBottom + 'px';
            
            if (isJumping) {
                requestAnimationFrame(animateJump);
            }
        }
        
        requestAnimationFrame(animateJump);
    }
}

document.addEventListener('keydown', (event) => {
    if (event.code === 'Space' || event.code === 'ArrowUp') { 
        jump();
        event.preventDefault();
    }
});

function createObstacle() {
    if (!gameActive) return;

    const obstacle = document.createElement('div');
    obstacle.classList.add('obstacle');
    gameBoard.appendChild(obstacle);

    let obstaclePosition = 900;
    obstacle.style.left = obstaclePosition + 'px';

    const moveInterval = setInterval(() => {
        if (!gameActive) {
            clearInterval(moveInterval);
            return;
        }

        const sonicLeft = parseInt(window.getComputedStyle(sonic).getPropertyValue('left'));
        
        const obstacleLeft = parseInt(obstacle.style.left);
        
        const sonicWidth = 65;
        const obstacleWidth = 40;
        const obstacleHeight = 40; 
        const groundHeight = 0;


        const horizontalOverlap = obstacleLeft < sonicLeft + sonicWidth && 
                                  obstacleLeft + obstacleWidth > sonicLeft;

        const verticalOverlap = sonicBottom < obstacleHeight - groundHeight; 

        if (horizontalOverlap && verticalOverlap) { 
            
            clearInterval(moveInterval);
            stopGame();
  
            sonic.style.backgroundImage = "url('images/sonic_over.png')"; 
            sonic.style.transform = 'scale(1)';

            setTimeout(() => {
                alert(`Game Over! Seu Score final foi: ${score}`);
                window.location.reload();
            }, 100);

        } else if (obstacleLeft < -obstacleWidth) {
            clearInterval(moveInterval);
            if (gameBoard.contains(obstacle)) {
                gameBoard.removeChild(obstacle);
                updateScore();
            }
        } else {
            obstaclePosition -= gameSpeed;
            obstacle.style.left = obstaclePosition + 'px';
        }
    }, 20);
}

function updateScore() {
    score += 1;
    scoreText.innerText = score;

    if (score > 0 && score % 10 === 0) {
        gameSpeed += 0.5;
        console.log("Velocidade aumentada! Nova velocidade: " + gameSpeed);
    }
}

function stopGame() {
    gameActive = false;
    clearTimeout(obstacleSpawnInterval);
    document.querySelectorAll('.obstacle').forEach(obstacle => {
    });
}

function spawnObstaclesLoop() {
    if (!gameActive) return;

    createObstacle();
    
    const minTime = Math.max(700, 2500 - (gameSpeed * 100));
    const maxTime = Math.max(1500, 3500 - (gameSpeed * 150));
    const randomTime = Math.random() * (maxTime - minTime) + minTime;
    
    console.log("Próximo obstáculo em: " + randomTime.toFixed(0) + "ms");
    
    obstacleSpawnInterval = setTimeout(spawnObstaclesLoop, randomTime);
}

spawnObstaclesLoop();